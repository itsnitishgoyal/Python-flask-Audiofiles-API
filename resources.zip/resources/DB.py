import pyodbc
import yaml
import logging
import pandas as pd
from flask import jsonify

logging.basicConfig(filename="LOG_music" + '.log', level=logging.INFO,
                    format='%(asctime)s:%(levelname)s:%(message)s')
class dboperation():
    def __init__(self):
        self.response_failure = {"message": "request body validation failure",
                            "status": 400
                            }
        #use below if we need server configurable
        '''
        try:
            with open(r'config.yml') as file:
                config_list = yaml.load(file, Loader=yaml.FullLoader)
                self.server = config_list['Server']
                self.dbname = config_list['Database']
        except Exception as e:
            logging.error(e)'''

    def DB_song_insert(self,data):
        try:
            response_message={}
            print("in deb song insertion")
            cnxn = pyodbc.connect(r'Driver=SQL Server;Server=test;Database=music_database;Trusted_Connection=yes;')
            cursor = cnxn.cursor()
            data_id= data["data"]["id"]
            data_name=data["data"]["name"]
            data_duration= data["data"]["duration"]
            data_uploadtime=data["data"]["uploadtime"]
            df = pd.read_sql("SELECT ID FROM songs",cnxn)
            if data_id in df['ID'].values:
                response_message['message']="Id Already exist please send uinqueid"
                response_message['statuscode']=400
                return response_message
            else:
                sqlquery = "INSERT INTO songs (ID, SONG, DURATION,UPLOADED_TIME) VALUES ({}, '{}',{},'{}')".format(data_id,data_name,data_duration,data_uploadtime)
                cursor.execute(sqlquery)
                cnxn.commit()
                cnxn.close()
                response_message['message']="Successfully created the entry"
                response_message['statuscode']=200
                return response_message
        except Exception as e:
            logging.error(e)
            return self.response_failure



    def DB_podcast_insert(self,data):
        try:
            response_message={}
            print("in deb song insertion")
            cnxn = pyodbc.connect(r'Driver=SQL Server;Server=test;Database=music_database;Trusted_Connection=yes;')
            cursor = cnxn.cursor()
            data_id= data["data"]["id"]
            data_name=data["data"]["name"]
            data_duration= data["data"]["duration"]
            data_uploadtime=data["data"]["uploadtime"]
            data_host = data["data"]["host"]
            data_participants = data["data"]["participants"]
            participants_string = ','.join(map(str, data_participants))
            #print((participants_string))
            df = pd.read_sql("SELECT ID FROM podcast",cnxn)
            if data_id in df['ID'].values:
                response_message['message']="Id Already exist please send uinqueid"
                response_message['statuscode']=400
                return response_message
            else:
                sqlquery = "INSERT INTO podcast (ID, PODCAST, DURATION,UPLOADED_TIME,HOST,PARTICIPANTS) VALUES ({}, '{}',{},'{}','{}','{}')".format(data_id,data_name,data_duration,data_uploadtime,data_host,participants_string)
                cursor.execute(sqlquery)
                cnxn.commit()
                cnxn.close()
                response_message['message']="Successfully created the entry"
                response_message['statuscode']=200
                return response_message
        except Exception as e:
            logging.error(e)
            return  self.response_failure



    def DB_audiobook_insert(self,data):
        try:
            response_message={}
            print("in deb song insertion")
            cnxn = pyodbc.connect(r'Driver=SQL Server;Server=test;Database=music_database;Trusted_Connection=yes;')
            cursor = cnxn.cursor()
            data_id= data["data"]["id"]
            data_name=data["data"]["name"]
            data_duration= data["data"]["duration"]
            data_uploadtime=data["data"]["uploadtime"]
            data_author= data["data"]["author"]
            data_narrator = data["data"]["narrator"]
            df = pd.read_sql("SELECT ID FROM audiobook",cnxn)
            if data_id in df['ID'].values:
                response_message['message']="Id Already exist please send uinqueid"
                response_message['statuscode']=400
                return response_message
            else:
                sqlquery = "INSERT INTO audiobook (ID, AUDIOBOOK,AUTHOR,NARRATOR, DURATION,UPLOADED_TIME) VALUES ({}, '{}','{}','{}',{},'{}')".format(data_id,data_name,data_author,data_narrator,data_duration,data_uploadtime)
                cursor.execute(sqlquery)
                cnxn.commit()
                cnxn.close()
                response_message['message']="Successfully created the entry"
                response_message['statuscode']=200
                return response_message
        except Exception as e:
            logging.error(e)
            return self.response_failure

    def DB_song_update(self,data):
        try:
            response_message={}
            print("in deb song insertion")
            cnxn = pyodbc.connect(r'Driver=SQL Server;Server=test;Database=music_database;Trusted_Connection=yes;')
            cursor = cnxn.cursor()
            data_id= data["data"]["id"]
            data_name=data["data"]["name"]
            data_duration= data["data"]["duration"]
            data_uploadtime=data["data"]["uploadtime"]
            df = pd.read_sql("SELECT ID FROM songs",cnxn)
            if data_id not in df['ID'].values:
                response_message['message']="Id not exist"
                response_message['statuscode']=400
                return response_message
            else:
                sqlquery= "UPDATE songs SET SONG= '{}', DURATION = {}, UPLOADED_TIME='{}' WHERE ID = {}".format(data_name,data_duration,data_uploadtime,data_id)
                cursor.execute(sqlquery)
                cnxn.commit()
                cnxn.close()
                response_message['message']="Successfully updated the entry"
                response_message['statuscode']=200
                return response_message
        except Exception as e:
            logging.error(e)
            return self.response_failure



    def DB_podcast_update(self,data):
        try:
            response_message={}
            print("in deb song insertion")
            cnxn = pyodbc.connect(r'Driver=SQL Server;Server=test;Database=music_database;Trusted_Connection=yes;')
            cursor = cnxn.cursor()
            data_id= data["data"]["id"]
            data_name=data["data"]["name"]
            data_duration= data["data"]["duration"]
            data_uploadtime=data["data"]["uploadtime"]
            data_host = data["data"]["host"]
            data_participants = data["data"]["participants"]
            participants_string = ','.join(map(str, data_participants))
            #print((participants_string))
            df = pd.read_sql("SELECT ID FROM podcast",cnxn)
            if data_id not in df['ID'].values:
                response_message['message']="Id not exist"
                response_message['statuscode']=400
                return response_message
            else:
                sqlquery = "UPDATE podcast SET PODCAST= '{}', DURATION = {}, UPLOADED_TIME='{}',HOST='{}',PARTICIPANTS='{}' WHERE ID = {}".format(data_name, data_duration, data_uploadtime,data_host,participants_string,data_id)
                #print(sqlquery)
                cursor.execute(sqlquery)
                cnxn.commit()
                cnxn.close()
                response_message['message']="Successfully updated the entry"
                response_message['statuscode']=200
                return response_message
        except Exception as e:
            logging.error(e)
            return  self.response_failure



    def DB_audiobook_update(self,data):
        try:
            response_message={}
            print("in deb song insertion")
            cnxn = pyodbc.connect(r'Driver=SQL Server;Server=test;Database=music_database;Trusted_Connection=yes;')
            cursor = cnxn.cursor()
            data_id= data["data"]["id"]
            data_name=data["data"]["name"]
            data_duration= data["data"]["duration"]
            data_uploadtime=data["data"]["uploadtime"]
            data_author= data["data"]["author"]
            data_narrator = data["data"]["narrator"]
            df = pd.read_sql("SELECT ID FROM audiobook",cnxn)
            if data_id not in df['ID'].values:
                response_message['message']="Id not exist"
                response_message['statuscode']=400
                return response_message
            else:
                sqlquery = "UPDATE audiobook SET AUDIOBOOK= '{}',AUTHOR='{}',NARRATOR='{}', DURATION = {}, UPLOADED_TIME='{}' WHERE ID = {}".format(data_name, data_author,data_narrator,data_duration, data_uploadtime, data_id)
                cursor.execute(sqlquery)
                cnxn.commit()
                cnxn.close()
                response_message['message']="Successfully updated the entry"
                response_message['statuscode']=200
                return response_message
        except Exception as e:
            logging.error(e)
            return self.response_failure

    def DB_get(self, audioFileType, audioFileID):
        try:
            response_message = {}
            cnxn = pyodbc.connect(r'Driver=SQL Server;Server=test;Database=music_database;Trusted_Connection=yes;')
            cursor = cnxn.cursor()
            if audioFileType=='song':
                audioFileType = 'songs'
            sqlquery= "select * from {} where ID={}".format(audioFileType,audioFileID)
            DataFrame = pd.read_sql(sqlquery, cnxn)
            sql_record=DataFrame.to_json(orient="records")
            response_message["type"]=audioFileType
            response_message["data"] = sql_record

            cnxn.commit()
            cnxn.close()
            return response_message
        except Exception as e:
            logging.error(e)
    def DB_del(self, audioFileType, audioFileID):
        try:
            response_message = {}
            cnxn = pyodbc.connect(r'Driver=SQL Server;Server=test;Database=music_database;Trusted_Connection=yes;')
            cursor = cnxn.cursor()
            if audioFileType=='song':
                audioFileType = 'songs'
            sqlquery= "delete from {} where ID={}".format(audioFileType,audioFileID)
            cursor.execute(sqlquery)
            cnxn.commit()
            cnxn.close()
            response_message["message"]= "successfully deleted the record for id {}".format(audioFileID)
            print(response_message)
            return response_message
        except Exception as e:
            logging.error(e)

    def DB_getallfiles(self, audioFileType):
        try:
            response_message = {}
            cnxn = pyodbc.connect(r'Driver=SQL Server;Server=test;Database=music_database;Trusted_Connection=yes;')
            cursor = cnxn.cursor()
            if audioFileType == 'song':
                audioFileType = 'songs'
            sqlquery = "select * from {} ".format(audioFileType)
            DataFrame = pd.read_sql(sqlquery, cnxn)
            sql_record = DataFrame.to_json(orient="records")
            response_message["type"] = audioFileType
            response_message["data"] = sql_record

            cnxn.commit()
            cnxn.close()
            return response_message
        except Exception as e:
            logging.error(e)