from flask import Flask,jsonify,request
from flask_restful import Api,Resource
import logging
from resources.DB import dboperation
logging.basicConfig(filename="restoperation_music" + '.log', level=logging.INFO,
                    format='%(asctime)s:%(levelname)s:%(message)s')
class getallfiles(Resource):
    def get(self, audioFileType):
        try:
            logging.info("Client requested to get all the data")
            db_obj_get = dboperation()
            response_to_client=db_obj_get.DB_getallfiles(audioFileType)
            return response_to_client,200
        except Exception as e:
            logging.error(e)