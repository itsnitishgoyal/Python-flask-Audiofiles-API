from flask import Flask,jsonify,request
from flask_restful import Api,Resource
import logging
from resources.DB import dboperation
logging.basicConfig(filename="LOG_music" + '.log', level=logging.INFO,
                    format='%(asctime)s:%(levelname)s:%(message)s')
class audiofiles(Resource):
    def post(self):
        try:
            #print("test")
            logging.info("Client requested to post the data")
            posted_data=request.get_json()
            response_to_client= self.data_insertion(posted_data)
            return response_to_client,response_to_client['statuscode']
        except Exception as e:
            logging.error(e)
    def data_insertion(self,data):
        try:
            response_failure= {"message": "request body validation failure",
                           "status": 400
                            }
            response_validation=False
            db_obj = dboperation()
            if data["type"] == "song":
                response_validation= self.validate_song(data)
                if response_validation == True:
                    response_message=db_obj.DB_song_insert(data)
                else:
                    response_message=response_failure
            elif data["type"] == "podcast":
                response_validation = self.validate_podcast(data)
                if response_validation == True:
                    response_message=db_obj.DB_podcast_insert(data)
                else:
                    response_message=response_failure
            elif data["type"] == "audiobook":
                response_validation = self.validate_audiobook(data)
                if response_validation == True:
                    response_message=db_obj.DB_audiobook_insert(data)
                else:
                    response_message=response_failure
            else:
                response_message={"message": "not supported music type",
                               "statuscode": 400
                                }
            return response_message
        except Exception as e:
            logging.error(e)
    def validate_song(self,data):
        try:
            flag=False
            if all(k in data["data"] for k in ("id", "name", "duration","uploadtime")):
                flag=True
            logging.info("validated the song input")
            return flag

        except Exception as e:
            logging.error(e)


    def validate_podcast(self,data):
        try:
            flag=False
            if all(k in data["data"] for k in ("id", "name", "duration","uploadtime","host","participants")):
                flag=True
            logging.info("validated the song input")
            return flag

        except Exception as e:
            logging.error(e)
    def validate_audiobook(self,data):
        try:
            flag=False
            if all(k in data["data"] for k in ("id", "name", "duration","uploadtime","author","narrator")):
                flag=True
            logging.info("validated the song input")
            return flag

        except Exception as e:
            logging.error(e)